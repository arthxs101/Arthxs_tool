package com.arthxs.tools;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.net.*;
import java.io.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private final int BG = Color.rgb(15, 23, 42);
    private final int PANEL = Color.rgb(30, 41, 59);
    private final int ACCENT = Color.rgb(56, 189, 248);
    private LinearLayout root, content;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private String expression = "";
    private TextView calcDisplay;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setPadding(dp(16), dp(18), dp(16), dp(12));
        setContentView(root);

        TextView title = new TextView(this);
        title.setText("ARTHXS TOOLS");
        title.setTextColor(Color.WHITE);
        title.setTextSize(23);
        title.setTypeface(null, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, dp(52)));

        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        root.addView(nav, new LinearLayout.LayoutParams(-1, dp(52)));
        addNav(nav, "Calendário", 0);
        addNav(nav, "Calculadora", 1);
        addNav(nav, "Clima", 2);

        ScrollView scroll = new ScrollView(this);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(0, dp(16), 0, dp(8));
        scroll.addView(content);
        showCalendar();
    }

    private void addNav(LinearLayout nav, String label, int page) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(11);
        b.setTextColor(Color.WHITE);
        b.setAllCaps(false);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(PANEL));
        nav.addView(b, new LinearLayout.LayoutParams(0, -1, 1));
        b.setOnClickListener(v -> {
            if (page == 0) showCalendar();
            if (page == 1) showCalculator();
            if (page == 2) showWeather();
        });
    }

    private void heading(String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(Color.WHITE);
        t.setTextSize(21);
        t.setTypeface(null, Typeface.BOLD);
        t.setPadding(0, dp(8), 0, dp(16));
        content.addView(t);
    }

    private void showCalendar() {
        content.removeAllViews();
        heading("Calendário");
        CalendarView calendar = new CalendarView(this);
        calendar.setBackgroundColor(PANEL);
        content.addView(calendar, new LinearLayout.LayoutParams(-1, dp(340)));
        TextView note = new TextView(this);
        note.setText("Toque em uma data para selecioná-la.");
        note.setTextColor(Color.LTGRAY);
        note.setPadding(0, dp(14), 0, 0);
        content.addView(note);
        calendar.setOnDateChangeListener((view, year, month, day) ->
            note.setText(String.format("Data selecionada: %02d/%02d/%04d", day, month + 1, year)));
    }

    private void showCalculator() {
        content.removeAllViews();
        heading("Calculadora");
        calcDisplay = new TextView(this);
        calcDisplay.setText("0");
        calcDisplay.setTextColor(Color.WHITE);
        calcDisplay.setTextSize(32);
        calcDisplay.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        calcDisplay.setPadding(dp(12), 0, dp(12), 0);
        calcDisplay.setBackgroundColor(PANEL);
        content.addView(calcDisplay, new LinearLayout.LayoutParams(-1, dp(82)));

        String[][] keys = {{"7","8","9","÷"},{"4","5","6","×"},{"1","2","3","−"},{"C","0",".","+ "},{"="}};
        for (String[] row : keys) {
            LinearLayout line = new LinearLayout(this);
            line.setOrientation(LinearLayout.HORIZONTAL);
            content.addView(line, new LinearLayout.LayoutParams(-1, dp(66)));
            for (String key : row) {
                Button b = new Button(this);
                b.setText(key.trim());
                b.setTextSize(20);
                b.setTextColor(Color.WHITE);
                b.setAllCaps(false);
                b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(key.equals("=") ? ACCENT : PANEL));
                line.addView(b, new LinearLayout.LayoutParams(0, -1, 1));
                b.setOnClickListener(v -> onCalcKey(key.trim()));
            }
        }
    }

    private void onCalcKey(String key) {
        if (key.equals("C")) expression = "";
        else if (key.equals("=")) {
            try {
                double result = evaluate(expression);
                expression = (result == Math.rint(result)) ? Long.toString((long) result) : Double.toString(result);
            } catch (Exception e) { expression = "Erro"; }
        } else {
            if (expression.equals("Erro")) expression = "";
            expression += key;
        }
        calcDisplay.setText(expression.isEmpty() ? "0" : expression);
    }

    // Parser simples com precedência para +, -, × e ÷.
    private double evaluate(String s) {
        if (s.isEmpty()) throw new IllegalArgumentException();
        s = s.replace("×", "*").replace("÷", "/").replace("−", "-").replace(" ", "");
        java.util.ArrayList<Double> nums = new java.util.ArrayList<>();
        java.util.ArrayList<Character> ops = new java.util.ArrayList<>();
        int start = 0;
        for (int i = 1; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '+' || c == '-' || c == '*' || c == '/') {
                nums.add(Double.parseDouble(s.substring(start, i)));
                ops.add(c); start = i + 1;
            }
        }
        nums.add(Double.parseDouble(s.substring(start)));
        for (int i = 0; i < ops.size();) {
            char op = ops.get(i);
            if (op == '*' || op == '/') {
                double a = nums.get(i), b = nums.get(i + 1);
                if (op == '/' && b == 0) throw new ArithmeticException();
                nums.set(i, op == '*' ? a * b : a / b);
                nums.remove(i + 1); ops.remove(i);
            } else i++;
        }
        double result = nums.get(0);
        for (int i = 0; i < ops.size(); i++)
            result = ops.get(i) == '+' ? result + nums.get(i + 1) : result - nums.get(i + 1);
        if (!Double.isFinite(result)) throw new ArithmeticException();
        return result;
    }

    private void showWeather() {
        content.removeAllViews();
        heading("Previsão do tempo");
        TextView info = new TextView(this);
        info.setText("Digite uma cidade para consultar a previsão.");
        info.setTextColor(Color.LTGRAY);
        content.addView(info);
        EditText city = new EditText(this);
        city.setSingleLine(true);
        city.setHint("Ex.: Serra, ES");
        city.setTextColor(Color.WHITE);
        city.setHintTextColor(Color.GRAY);
        city.setPadding(dp(12), 0, dp(12), 0);
        city.setBackgroundColor(PANEL);
        LinearLayout.LayoutParams ep = new LinearLayout.LayoutParams(-1, dp(54));
        ep.topMargin = dp(14);
        content.addView(city, ep);
        Button search = new Button(this);
        search.setText("Consultar");
        search.setAllCaps(false);
        search.setTextColor(Color.WHITE);
        search.setBackgroundTintList(android.content.res.ColorStateList.valueOf(ACCENT));
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, dp(52));
        bp.topMargin = dp(10);
        content.addView(search, bp);
        TextView result = new TextView(this);
        result.setTextColor(Color.WHITE);
        result.setTextSize(17);
        result.setPadding(0, dp(20), 0, 0);
        content.addView(result);
        search.setOnClickListener(v -> {
            String place = city.getText().toString().trim();
            if (place.isEmpty()) { result.setText("Informe uma cidade."); return; }
            result.setText("Consultando...");
            fetchWeather(place, result);
        });
    }

    private void fetchWeather(String place, TextView output) {
        executor.execute(() -> {
            try {
                String geoUrl = "https://geocoding-api.open-meteo.com/v1/search?name=" +
                    URLEncoder.encode(place, "UTF-8") + "&count=1&language=pt&format=json";
                JSONObject geo = new JSONObject(get(geoUrl));
                JSONArray arr = geo.optJSONArray("results");
                if (arr == null || arr.length() == 0) throw new Exception("Cidade não encontrada.");
                JSONObject loc = arr.getJSONObject(0);
                double lat = loc.getDouble("latitude"), lon = loc.getDouble("longitude");
                String name = loc.optString("name", place);
                String admin = loc.optString("admin1", "");
                String url = "https://api.open-meteo.com/v1/forecast?latitude=" + lat +
                    "&longitude=" + lon + "&current=temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,wind_speed_10m&daily=temperature_2m_max,temperature_2m_min,precipitation_probability_max&timezone=auto&forecast_days=3";
                JSONObject data = new JSONObject(get(url));
                JSONObject current = data.getJSONObject("current");
                JSONObject daily = data.getJSONObject("daily");
                String description = weatherText(current.optInt("weather_code"));
                StringBuilder text = new StringBuilder();
                text.append(name).append(admin.isEmpty() ? "" : ", " + admin).append("\n\n");
                text.append(String.format(java.util.Locale.getDefault(), "%.1f °C · %s\n", current.getDouble("temperature_2m"), description));
                text.append("Sensação: ").append(current.optDouble("apparent_temperature")).append(" °C\n");
                text.append("Umidade: ").append(current.optInt("relative_humidity_2m")).append("%\n");
                text.append("Vento: ").append(current.optDouble("wind_speed_10m")).append(" km/h\n\n");
                text.append("Próximos dias:\n");
                JSONArray dates = daily.getJSONArray("time");
                JSONArray max = daily.getJSONArray("temperature_2m_max");
                JSONArray min = daily.getJSONArray("temperature_2m_min");
                JSONArray rain = daily.getJSONArray("precipitation_probability_max");
                for (int i = 0; i < dates.length(); i++) {
                    text.append(dates.getString(i)).append(": ")
                        .append(min.getDouble(i)).append("° / ").append(max.getDouble(i))
                        .append("° · chuva ").append(rain.optInt(i)).append("%\n");
                }
                final String finalText = text.toString();
                runOnUiThread(() -> output.setText(finalText));
            } catch (Exception e) {
                runOnUiThread(() -> output.setText("Não foi possível consultar: " + e.getMessage()));
            }
        });
    }

    private String get(String address) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(address).openConnection();
        c.setRequestMethod("GET");
        c.setConnectTimeout(10000);
        c.setReadTimeout(10000);
        try (InputStream in = c.getInputStream(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buf = new byte[4096]; int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            return out.toString("UTF-8");
        } finally { c.disconnect(); }
    }

    private String weatherText(int code) {
        if (code == 0) return "Céu limpo";
        if (code <= 3) return "Parcialmente nublado";
        if (code == 45 || code == 48) return "Neblina";
        if (code >= 51 && code <= 67) return "Garoa ou chuva";
        if (code >= 71 && code <= 77) return "Neve";
        if (code >= 80 && code <= 82) return "Pancadas de chuva";
        if (code >= 95) return "Trovoadas";
        return "Condição variável";
    }

    private int dp(int value) { return (int)(value * getResources().getDisplayMetrics().density + 0.5f); }
    @Override protected void onDestroy() { super.onDestroy(); executor.shutdownNow(); }
}
